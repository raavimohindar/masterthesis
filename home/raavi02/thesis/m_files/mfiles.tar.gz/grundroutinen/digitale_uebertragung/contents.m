% ##############################################################################
% ## Grundroutinen zur digitalen Modulation                                   ##
% ##############################################################################
%
% cpm        : Verzeichnis enthaelt Dateien zur 
%               Continuous Phase Modulation (CPM)
%
% linear     : Verzeichnis enthaelt Dateien zur linearen digitalen Modulation
%               (ASK, PAM, PSK, QAM)
%
% entzerrung : Verzeichnis enthaelt Dateien zur Entzerrung
%
% ### EOF ######################################################################
