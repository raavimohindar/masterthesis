% ##############################################################################
% ## Grundroutinen zu verketteten Codes                                       ##
% ##############################################################################
%
% analytisch  : Verzeichnis enthaelt Routinen zur analytischen Abschaetzung der
%               Bitfehlerraten, Berechnung der IOWEF von Codes, usw.
%
% simulativ   : Verzeichnis enthaelt Routinen zur Simulation von verketteten
%               Codes und iterativer Decodierung
%
% ### EOF ######################################################################
