% ##############################################################################
% ## Grundroutinen zur Kanalcodierung                                         ##
% ##############################################################################
%
% blockcodes    : Verzeichnis enthaelt Routinen zu linearen Blockcodes
%
% faltungscodes : Verzeichnis enthaelt Routinen zu Faltungscodes
%
% verkettung    : Verzeichnis enthaelt Routinen zur seriellen und parallelen
%                 Codeverkettung sowie zur iterativen Turbo-Decodierung
%
% ### EOF ######################################################################
