% ##############################################################################
% ## Grundroutinen zu OFDM                                                    ##
% ##############################################################################
%
% ofdm_auge.m : OFDM-Augendiagramm
%
% ofdm_dem.m  : OFDM-Demodulator mit Kanalschaetzung und Entzerrung
%
% ofdm_mod.m  : OFDM-Modulator
%
% ### EOF ######################################################################
