% ##############################################################################
% ## Grundroutinen zur Modellierung von Uebertragungskanaelen                 ##
% ##############################################################################
%
% ant_channel.m : Simulation von Mobilfunkkanaelen nach diversen COST-Profilen
%                  (auch frei konfigurierbar)
%
% ### EOF ######################################################################
