% ##############################################################################
% ## Grundroutinen zu Systemen                                                ##
% ##############################################################################
%
% kanalmodelle  : Verzeichnis enthaelt Routinen zur  Modellierung von
%                  Uebertragungskanaelen
%
% ofdm          : Verzeichnis enthaelt Routinen zu OFDM
%
% cdma          : Verzeichnis enthaelt Routinen zu CDMA   
%
% systemtheorie : Verzeichnis enthaelt Routinen zur Systemtheorie
%
% ### EOF ######################################################################
