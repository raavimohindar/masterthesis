% ##############################################################################
% ## Grundroutinen zu den Matlab-Uebungen                                     ##
% ##############################################################################
%
% analoge_modulation   : Verzeichnis enthaelt Dateien zur analogen Modulation
%
% codierung            : Verzeichnis enthaelt Dateien zur Kanalcodierung
%                        (lineare Blockcodes, Faltungscodes, verkettete Codes)
%
% digitale_uebertragung: Verzeichnis enthaelt Dateien zur digitalen Uebertragung
%
% systeme              : Verzeichnis enthaelt Dateien zur Signal- und
%                        Systemtheorie
%
% ### EOF ######################################################################
